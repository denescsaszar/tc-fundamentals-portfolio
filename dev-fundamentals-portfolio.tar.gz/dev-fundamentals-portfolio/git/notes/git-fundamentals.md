# 📄 git-fundamentals.md
## Git: Version Control From First Commit to Pull Requests

> **Goal:** Use Git confidently for daily development — committing, branching, collaborating, and shipping.

---

## 1. What is Git?

Git is a **distributed version control system**. It tracks changes to files over time, letting you revert mistakes, collaborate without overwriting each other's work, and maintain a full history of every decision your codebase has ever made.

> **Why this matters:** Git is non-negotiable in professional development. Every team uses it. Every job posting lists it. A GitHub portfolio is your public proof that you know how to work in a team.

> ⚠️ **Common mistake:** Treating Git like a backup tool — committing "save point" once a day with a vague message like `update`. Commits are a changelog. Write them for the developer who reads your history 6 months from now.

---

## 2. Core Concepts (Mental Model First)

Before commands, get the model right:

```
Working Directory  →  Staging Area (Index)  →  Local Repo  →  Remote (GitHub)
     (your files)         (git add)           (git commit)     (git push)
```

- **Working Directory:** Files on your machine that you're editing
- **Staging Area:** A preview of what your next commit will contain
- **Local Repository:** Your complete history, stored in `.git/`
- **Remote:** GitHub, GitLab, Bitbucket — the shared copy your team works with

---

## 3. Essential Commands

### Setup (one-time)

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git config --global core.editor "code --wait"  # Use VS Code as editor
```

### Starting a project

```bash
# Initialize a new repo in the current folder
git init

# Clone an existing repo from GitHub
git clone https://github.com/username/repo-name.git

# Clone into a specific folder
git clone https://github.com/username/repo-name.git my-folder
```

### The daily workflow

```bash
# Check what's changed
git status

# See the actual diff
git diff

# Stage specific files
git add README.md

# Stage all changes in current directory
git add .

# Stage interactively (choose chunks)
git add -p

# Commit with a message
git commit -m "add: JSON parsing example for config files"

# Commit all tracked changes without separate add
git commit -am "fix: handle null values in parser"
```

### Syncing with GitHub

```bash
# Download changes from remote (doesn't modify working files)
git fetch origin

# Download AND merge into current branch
git pull origin main

# Upload your commits to GitHub
git push origin main

# Push a new branch and set it to track the remote
git push -u origin feature/json-parser
```

> **Why this matters:** `fetch` vs `pull` is a common source of confusion. Use `fetch` to see what's changed remotely before deciding to merge. Use `pull` when you're ready to integrate.

> ⚠️ **Common mistake:** Pushing directly to `main` on a team project. Always work on a branch. `main` should only receive changes via pull requests.

---

## 4. Branching Strategy

Branches are cheap and fast in Git. Use them aggressively.

### Create and switch branches

```bash
# Create a new branch
git branch feature/add-xml-validator

# Switch to it
git checkout feature/add-xml-validator

# Shortcut: create and switch in one command
git checkout -b feature/add-xml-validator

# Modern equivalent (Git 2.23+)
git switch -c feature/add-xml-validator

# List all branches (* = current)
git branch

# List branches including remote
git branch -a
```

### Naming convention (use this)

```
main          ← stable, deployable code
develop       ← integration branch (optional for solo projects)
feature/...   ← new functionality: feature/json-schema-validation
fix/...       ← bug fixes: fix/null-pointer-in-parser
chore/...     ← maintenance: chore/update-dependencies
docs/...      ← documentation: docs/add-xml-readme
```

> **Why this matters:** Branch naming is how your team knows what's in progress, what's a fix, and what's documentation — without reading the code.

> ⚠️ **Common mistake:** Long-lived branches. A feature branch that drifts from `main` for weeks becomes a merge nightmare. Merge or rebase frequently (at least every 2 days on active projects).

---

## 5. Merge vs. Rebase

Both integrate changes from one branch into another. They produce different histories.

### Merge — Preserves history, adds a merge commit

```bash
git checkout main
git merge feature/add-xml-validator
```

History looks like:
```
* Merge branch 'feature/add-xml-validator'
|\
| * add XSD validation for books.xml
| * add books.xml test fixture
* | fix: update README
|/
* initial commit
```

### Rebase — Rewrites history, linear and clean

```bash
git checkout feature/add-xml-validator
git rebase main
```

History looks like:
```
* add XSD validation for books.xml
* add books.xml test fixture
* fix: update README
* initial commit
```

| | Merge | Rebase |
|-|-------|--------|
| History | Preserves branching | Linear, cleaner |
| Safety | Safe on shared branches | **Never rebase shared/public branches** |
| Use when | Integrating into `main` | Cleaning up before a PR |

> **Why this matters:** Recruiters and code reviewers read Git history. A clean, linear history signals a developer who thinks before committing.

> ⚠️ **Common mistake:** Rebasing `main` or any branch other people are using. Rebase rewrites commit hashes — it breaks everyone else's local copies.

---

## 6. Pull Requests

A **pull request (PR)** is a request to merge your branch into another. It's where code review happens.

### Workflow

```bash
# 1. Create a branch
git checkout -b feature/json-config-parser

# 2. Do your work, commit
git add config-parser.js
git commit -m "feat: add JSON config file parser with error handling"

# 3. Push to GitHub
git push -u origin feature/json-config-parser

# 4. Open a PR on GitHub (UI or CLI)
gh pr create --title "feat: JSON config parser" --body "Adds parser with try/catch and schema validation"
```

### Good PR description template

```markdown
## What this PR does
Adds a JSON config file parser that validates against a schema and handles parse errors gracefully.

## Why
Config parsing previously crashed on malformed JSON. This PR makes it resilient.

## How to test
1. Run `node parse.js` with `config.json`
2. Try with `broken-config.json` to see the error handler in action

## Checklist
- [x] Tested manually
- [x] README updated
- [x] No console.log left in
```

> **Why this matters:** A well-written PR is a communication tool. It tells the reviewer *why* you made the change, not just *what* changed. That's what separates junior from senior contributors.

> ⚠️ **Common mistake:** Opening a PR with hundreds of lines changed and a one-word description. Small, focused PRs get reviewed faster and merged sooner.

---

## 7. .gitignore

The `.gitignore` file tells Git which files to never track.

```gitignore
# Dependencies
node_modules/

# OS files
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*

# Environment variables (never commit secrets)
.env
.env.local
.env.*.local

# Build output
dist/
build/
*.min.js

# Editor files
.cursor/
.vscode/settings.json
*.swp

# Test coverage
coverage/
```

> **Why this matters:** Committing `node_modules/` (200MB+), `.env` files (API keys), or editor temp files pollutes your repo and exposes secrets. Never commit credentials — not even "just for a second."

> ⚠️ **Common mistake:** Creating `.gitignore` after already committing the files you want to ignore. You need to remove them from tracking first: `git rm -r --cached node_modules/`

---

## 8. Tagging

Tags mark specific commits as meaningful — usually releases.

```bash
# Create a lightweight tag
git tag v1.0.0

# Create an annotated tag (preferred — includes metadata)
git tag -a v1.0.0 -m "First stable release"

# List tags
git tag

# Push tags to GitHub (not pushed with git push by default)
git push origin --tags

# Push a specific tag
git push origin v1.0.0
```

> **Why this matters:** Tags are how you mark what's deployed. GitHub turns annotated tags into releases automatically.

---

## 9. GitHub Actions — Intro

GitHub Actions automates workflows: run tests on every push, validate files, deploy on merge to `main`.

### Example: validate JSON files on push

Create `.github/workflows/validate.yml`:

```yaml
name: Validate JSON

on:
  push:
    branches: [main, "feature/**"]
  pull_request:

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repo
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: "20"

      - name: Validate JSON files
        run: |
          for file in $(find . -name "*.json" -not -path "*/node_modules/*"); do
            echo "Validating $file"
            node -e "JSON.parse(require('fs').readFileSync('$file','utf8'))" && echo "✓ Valid" || echo "✗ Invalid"
          done
```

> **Why this matters:** Automated checks catch mistakes before they reach `main`. This is the foundation of CI/CD — the practice that ships software reliably.

> ⚠️ **Common mistake:** Writing Actions workflows with hardcoded secrets in the YAML. Use GitHub repository Secrets (`Settings → Secrets`) and reference them as `${{ secrets.MY_API_KEY }}`.

---

## Git Commit Message Convention

Use this format — it reads like a changelog:

```
type: short description (50 chars max)

Optional longer body explaining WHY, not WHAT.
The diff already shows what changed.
```

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `style`

```bash
# Good
git commit -m "feat: add XPath query support to XML parser"
git commit -m "fix: handle empty arrays in JSON stringify"
git commit -m "docs: add setup instructions to README"

# Bad
git commit -m "update"
git commit -m "stuff"
git commit -m "WIP"
```

---

## Self-Check

Before moving on, you should be able to:

- [ ] Initialize a repo and make your first commit
- [ ] Create a branch, make changes, and merge back to `main`
- [ ] Explain the difference between merge and rebase
- [ ] Write a `.gitignore` for a Node.js project
- [ ] Open a pull request on GitHub with a clear description
- [ ] Explain what a GitHub Action does and when to use one
