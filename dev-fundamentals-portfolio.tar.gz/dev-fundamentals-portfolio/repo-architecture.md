# 📁 repo-architecture.md
## GitHub Portfolio Repo: `dev-fundamentals-portfolio`

> This repository is your **living learning journal and public portfolio**. Every file you create here is evidence of real skill — treat it that way from day one.

---

## Folder Structure

```
dev-fundamentals-portfolio/
│
├── README.md                          ← Portfolio homepage (recruiter-facing)
│
├── json/
│   ├── README.md                      ← What's in this folder + what you learned
│   ├── notes/
│   │   └── json-fundamentals.md       ← Study script + concept notes
│   └── projects/
│       ├── beginner-syntax/
│       │   ├── config.json
│       │   └── README.md
│       ├── intermediate-api-feed/
│       │   ├── feed.json
│       │   ├── parse.js
│       │   └── README.md
│       └── advanced-json-to-xml/
│           ├── input.json
│           ├── output.xml
│           ├── convert.js
│           └── README.md
│
├── xml/
│   ├── README.md
│   ├── notes/
│   │   └── xml-fundamentals.md
│   └── projects/
│       ├── beginner-elements/
│       │   ├── library.xml
│       │   └── README.md
│       ├── intermediate-validation/
│       │   ├── books.xml
│       │   ├── books.xsd
│       │   └── README.md
│       └── advanced-xslt-transform/
│           ├── catalog.xml
│           ├── transform.xsl
│           ├── output.html
│           └── README.md
│
├── git/
│   ├── README.md
│   ├── notes/
│   │   └── git-fundamentals.md
│   └── projects/
│       ├── beginner-first-commit/
│       │   └── README.md
│       ├── intermediate-branch-workflow/
│       │   └── README.md
│       └── advanced-github-actions/
│           ├── .github/
│           │   └── workflows/
│           │       └── validate.yml
│           └── README.md
│
├── notes/
│   ├── README.md                      ← Index of all study notes
│   └── cheatsheets/
│       ├── json-cheatsheet.md
│       ├── xml-cheatsheet.md
│       └── git-cheatsheet.md
│
├── tasks/
│   ├── README.md                      ← Task index + completion tracker
│   └── cursor-tasks.md                ← All 9 hands-on tasks
│
└── resources/
    ├── README.md
    └── curated-resources.md           ← Vetted free learning links
```

---

## Folder Purpose Rationale

| Folder | Purpose |
|--------|---------|
| `json/` | All JSON learning material and portfolio projects |
| `xml/` | All XML learning material and portfolio projects |
| `git/` | Git concept notes and workflow demonstrations |
| `notes/` | Quick-reference cheatsheets you build as you learn |
| `tasks/` | Cursor-based coding tasks with completion tracking |
| `resources/` | Curated external links — your personal bookmark vault |

---

## Setup Instructions

### 1. Create the repo on GitHub

```bash
# In your terminal
gh repo create dev-fundamentals-portfolio --public --clone
cd dev-fundamentals-portfolio
```

Or create it manually at [github.com/new](https://github.com/new) with:
- Name: `dev-fundamentals-portfolio`
- Visibility: **Public** (recruiters need to see this)
- Initialize with a README: **Yes**

### 2. Clone and scaffold locally

```bash
git clone https://github.com/YOUR_USERNAME/dev-fundamentals-portfolio.git
cd dev-fundamentals-portfolio

# Create folder structure
mkdir -p json/notes json/projects/{beginner-syntax,intermediate-api-feed,advanced-json-to-xml}
mkdir -p xml/notes xml/projects/{beginner-elements,intermediate-validation,advanced-xslt-transform}
mkdir -p git/notes git/projects/{beginner-first-commit,intermediate-branch-workflow,advanced-github-actions}
mkdir -p notes/cheatsheets tasks resources

# Create placeholder READMEs
touch json/README.md xml/README.md git/README.md notes/README.md tasks/README.md resources/README.md
```

### 3. Set up .gitignore

```bash
cat > .gitignore << 'EOF'
.DS_Store
node_modules/
*.log
.env
.cursor/
EOF
```

---

## Per-Folder README Template

Every project subfolder gets a `README.md` with this structure:

```markdown
# Project Name

**Topic:** JSON / XML / Git  
**Level:** Beginner / Intermediate / Advanced  
**Time to complete:** ~30 min  

## What I built
One sentence describing the output.

## What I learned
- Concept 1
- Concept 2

## How to run
Step-by-step instructions to execute or view the project.

## Key file
`filename.ext` — what it does and why it matters.
```

---

## Portfolio Mindset

> Every commit message, every README, every file name is visible to anyone who visits your repo. Write as if a senior dev is reading over your shoulder — because they might be.

- Use **clear, descriptive commit messages**: `add: JSON schema validation for books.json` not `update stuff`
- Keep projects **self-contained**: each project folder should work on its own
- Update folder READMEs **as you complete tasks** — don't leave them empty
