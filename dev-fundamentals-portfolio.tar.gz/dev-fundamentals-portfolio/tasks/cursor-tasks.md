# 📄 cursor-tasks.md
## All 9 Cursor Coding Tasks

> **How to use these tasks:**
> 1. Open Cursor in your `dev-fundamentals-portfolio` repo
> 2. Navigate to the correct project subfolder before starting
> 3. Read the full task before writing a single line
> 4. Commit your work when done: `git commit -m "feat: complete [task name]"`
> 5. Each task is self-contained and completable in under 45 minutes

---

# JSON Tasks

---

## Task J1 — Beginner: Build a Config File

**Folder:** `json/projects/beginner-syntax/`  
**Time:** ~20 minutes  
**What you'll produce:** `config.json` + `README.md`

### Instructions

You're setting up a config file for a web application. Create a file called `config.json` that represents the following requirements:

1. An `app` section with:
   - `name` (string): your app's name
   - `version` (string): use semantic versioning format like `"1.0.0"`
   - `debug` (boolean): set to `false`

2. A `server` section with:
   - `host` (string): `"localhost"`
   - `port` (number): `3000`
   - `https` (boolean): `false`

3. A `database` section with:
   - `url` (string)
   - `poolSize` (number): `5`
   - `ssl` (boolean)

4. A `features` object with at least 4 feature flags (booleans):
   - `darkMode`, `notifications`, `analytics`, `betaFeatures`

5. An `allowedOrigins` array with at least 2 strings

### Scaffold

```json
{
  "app": {
    
  },
  "server": {
    
  },
  "database": {
    
  },
  "features": {
    
  },
  "allowedOrigins": []
}
```

### Validation

After completing the file, run this in your terminal to validate it:

```bash
node -e "
  const fs = require('fs');
  try {
    const cfg = JSON.parse(fs.readFileSync('./config.json', 'utf8'));
    console.log('✓ Valid JSON');
    console.log('✓ App name:', cfg.app.name);
    console.log('✓ Server port:', cfg.server.port);
    console.log('✓ Features:', Object.keys(cfg.features).join(', '));
    console.log('✓ Origins:', cfg.allowedOrigins.length, 'entries');
  } catch(e) {
    console.error('✗ Error:', e.message);
  }
"
```

### Deliverable

A `config.json` that passes the validation script, plus a `README.md` explaining what the config represents and one thing you learned.

---

## Task J2 — Intermediate: Parse a JSON API Feed

**Folder:** `json/projects/intermediate-api-feed/`  
**Time:** ~35 minutes  
**What you'll produce:** `feed.json` + `parse.js` + `README.md`

### Instructions

You'll simulate fetching an API response and extracting useful data from it.

**Step 1:** Create `feed.json` — a mock API response for a book catalog:

```json
{
  "status": "ok",
  "timestamp": "2026-04-24T09:00:00Z",
  "data": {
    "books": [
      {
        "id": "B001",
        "title": "Clean Code",
        "author": "Robert C. Martin",
        "year": 2008,
        "available": true,
        "tags": ["programming", "best-practices"]
      },
      {
        "id": "B002",
        "title": "The Pragmatic Programmer",
        "author": "David Thomas",
        "year": 2019,
        "available": true,
        "tags": ["programming", "career"]
      },
      {
        "id": "B003",
        "title": "Design Patterns",
        "author": "Gang of Four",
        "year": 1994,
        "available": false,
        "tags": ["programming", "architecture"]
      },
      {
        "id": "B004",
        "title": "Refactoring",
        "author": "Martin Fowler",
        "year": 2018,
        "available": true,
        "tags": ["programming", "best-practices"]
      }
    ],
    "total": 4,
    "page": 1
  }
}
```

**Step 2:** Create `parse.js` that:

1. Reads `feed.json` from disk
2. Parses it safely (with try/catch)
3. Checks that `status === "ok"` before proceeding
4. Prints a formatted list of **only available books** with their title, author, and year
5. Counts and prints the total number of available books
6. Prints all unique tags across all books (no duplicates)

### Scaffold for `parse.js`

```javascript
const fs = require("fs");

// 1. Read and parse the file safely
let feed;
try {
  const raw = fs.readFileSync("./feed.json", "utf8");
  feed = JSON.parse(raw);
} catch (err) {
  console.error("Failed to parse feed.json:", err.message);
  process.exit(1);
}

// 2. Check status
if (feed.status !== "ok") {
  console.error("API returned non-ok status:", feed.status);
  process.exit(1);
}

const books = feed.data.books;

// 3. Filter available books
// TODO: filter books where available === true

// 4. Print each available book
// TODO: print title, author, year for each

// 5. Print count
// TODO: console.log total available

// 6. Print unique tags
// TODO: collect all tags, deduplicate, sort, print
```

### Expected output

```
Available Books:
─────────────────────────────────────
• Clean Code — Robert C. Martin (2008)
• The Pragmatic Programmer — David Thomas (2019)
• Refactoring — Martin Fowler (2018)

Total available: 3 of 4

All unique tags: architecture, best-practices, career, programming
```

### Run it

```bash
node parse.js
```

---

## Task J3 — Advanced: JSON-to-XML Converter

**Folder:** `json/projects/advanced-json-to-xml/`  
**Time:** ~45 minutes  
**What you'll produce:** `input.json` + `output.xml` + `convert.js` + `README.md`

### Instructions

Build a Node.js script that reads a JSON file and converts it to valid XML output. This task intentionally bridges JSON and XML — two technologies you now know.

**Step 1:** Create `input.json` (a product catalog):

```json
{
  "catalog": {
    "version": "1.0",
    "products": [
      {
        "id": "P001",
        "name": "Wireless Keyboard",
        "price": 49.99,
        "inStock": true,
        "tags": ["electronics", "peripherals"]
      },
      {
        "id": "P002",
        "name": "USB-C Hub",
        "price": 29.99,
        "inStock": false,
        "tags": ["electronics", "accessories"]
      },
      {
        "id": "P003",
        "name": "Mechanical Pencil Set",
        "price": 12.50,
        "inStock": true,
        "tags": ["stationery"]
      }
    ]
  }
}
```

**Step 2:** Create `convert.js` that:

1. Reads and parses `input.json`
2. Converts the data to XML format with:
   - A root `<catalog>` element with a `version` attribute
   - Each product as a `<product id="...">` element
   - `<name>`, `<price>`, `<inStock>` as child elements
   - `<tags>` element containing individual `<tag>` elements
3. Writes the result to `output.xml`
4. Validates the output is well-formed (check it opens and closes correctly)
5. Prints a success message with the number of products converted

### Expected `output.xml`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<catalog version="1.0">
  <product id="P001">
    <name>Wireless Keyboard</name>
    <price>49.99</price>
    <inStock>true</inStock>
    <tags>
      <tag>electronics</tag>
      <tag>peripherals</tag>
    </tags>
  </product>
  <product id="P002">
    <name>USB-C Hub</name>
    <price>29.99</price>
    <inStock>false</inStock>
    <tags>
      <tag>electronics</tag>
      <tag>accessories</tag>
    </tags>
  </product>
  <product id="P003">
    <name>Mechanical Pencil Set</name>
    <price>12.5</price>
    <inStock>true</inStock>
    <tags>
      <tag>stationery</tag>
    </tags>
  </product>
</catalog>
```

### Scaffold for `convert.js`

```javascript
const fs = require("fs");

function escapeXml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function productToXml(product, indent = "  ") {
  // TODO: build the <product> XML block
  // Use escapeXml() on all string values
}

function convertToXml(data) {
  const { catalog } = data;
  const lines = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<catalog version="${escapeXml(catalog.version)}">`,
    // TODO: map products to XML blocks
    "</catalog>"
  ];
  return lines.join("\n");
}

// Main
try {
  const raw = fs.readFileSync("./input.json", "utf8");
  const data = JSON.parse(raw);
  const xml = convertToXml(data);
  fs.writeFileSync("./output.xml", xml, "utf8");
  console.log(`✓ Converted ${data.catalog.products.length} products to output.xml`);
} catch (err) {
  console.error("Error:", err.message);
}
```

### Bonus challenge

Add a `--pretty` flag that formats the output with extra indentation and blank lines between products.

---

# XML Tasks

---

## Task X1 — Beginner: Build a Library Catalog in XML

**Folder:** `xml/projects/beginner-elements/`  
**Time:** ~20 minutes  
**What you'll produce:** `library.xml` + `README.md`

### Instructions

Create `library.xml` — a catalog of at least 5 books. Your XML must:

1. Have a proper XML declaration on line 1
2. Have a single root element `<library>` with a `name` attribute
3. Each `<book>` must have:
   - An `id` attribute (e.g., `B001`, `B002`)
   - A `category` attribute (`programming`, `fiction`, `science`, etc.)
   - Child elements: `<title>`, `<author>`, `<year>`, `<isbn>`, `<available>` (true/false)
4. At least one book must have a `<description>` child element containing multiple words
5. The file must be **well-formed** — validate it

### Scaffold

```xml
<?xml version="1.0" encoding="UTF-8"?>
<library name="My Dev Library">

  <book id="B001" category="programming">
    <title></title>
    <author></author>
    <year></year>
    <isbn></isbn>
    <available></available>
  </book>

  <!-- Add 4 more books here -->

</library>
```

### Validation

Paste your file into [xmlvalidation.com](https://www.xmlvalidation.com) or use VS Code XML extension. Fix any errors before committing.

### Deliverable

A well-formed `library.xml` with 5+ books and a `README.md` listing what you learned about XML syntax.

---

## Task X2 — Intermediate: Validate XML Against an XSD Schema

**Folder:** `xml/projects/intermediate-validation/`  
**Time:** ~35 minutes  
**What you'll produce:** `books.xml` + `books.xsd` + `README.md`

### Instructions

You'll write an XML document and the XSD schema that validates it — then intentionally break the XML to see what the validator reports.

**Step 1:** Create `books.xsd`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">

  <xs:element name="catalog">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="book" minOccurs="1" maxOccurs="unbounded">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="title" type="xs:string"/>
              <xs:element name="author" type="xs:string"/>
              <xs:element name="year">
                <xs:simpleType>
                  <xs:restriction base="xs:integer">
                    <xs:minInclusive value="1800"/>
                    <xs:maxInclusive value="2030"/>
                  </xs:restriction>
                </xs:simpleType>
              </xs:element>
              <xs:element name="price">
                <xs:simpleType>
                  <xs:restriction base="xs:decimal">
                    <xs:minInclusive value="0"/>
                  </xs:restriction>
                </xs:simpleType>
              </xs:element>
            </xs:sequence>
            <xs:attribute name="id" type="xs:ID" use="required"/>
            <xs:attribute name="category" type="xs:string" use="required"/>
          </xs:complexType>
        </xs:element>
      </xs:sequence>
    </xs:complexType>
  </xs:element>

</xs:schema>
```

**Step 2:** Create `books.xml` that validates against this schema:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<catalog xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="books.xsd">
  <!-- Add at least 3 books that match the schema exactly -->
</catalog>
```

**Step 3:** Validate online at [xmlvalidation.com](https://www.xmlvalidation.com).

**Step 4 (intentional breakage):** Copy `books.xml` to `books-invalid.xml`. Introduce 3 intentional errors:
- A year value of `1750` (below minimum)
- A missing required attribute
- A price of `-5` (below minimum)

Validate `books-invalid.xml` and **copy the error messages into your README.md**.

### Deliverable

`books.xml` (valid), `books-invalid.xml` (intentionally broken), `books.xsd`, and a `README.md` documenting the errors you found and what they mean.

---

## Task X3 — Advanced: XSLT Transformation to HTML

**Folder:** `xml/projects/advanced-xslt-transform/`  
**Time:** ~45 minutes  
**What you'll produce:** `catalog.xml` + `transform.xsl` + `output.html` + `README.md`

### Instructions

Transform an XML product catalog into a styled HTML page using XSLT.

**Step 1:** Create `catalog.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<catalog>
  <product id="P001" category="electronics">
    <name>Wireless Keyboard</name>
    <price currency="EUR">49.99</price>
    <inStock>true</inStock>
    <description>Compact wireless keyboard with 2-year battery life.</description>
  </product>
  <product id="P002" category="electronics">
    <name>USB-C Hub</name>
    <price currency="EUR">29.99</price>
    <inStock>false</inStock>
    <description>7-in-1 hub with HDMI, USB-A, SD card reader.</description>
  </product>
  <product id="P003" category="stationery">
    <name>Mechanical Pencil Set</name>
    <price currency="EUR">12.50</price>
    <inStock>true</inStock>
    <description>Set of 3 mechanical pencils with spare lead.</description>
  </product>
</catalog>
```

**Step 2:** Create `transform.xsl` — an XSLT stylesheet that produces an HTML table:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" doctype-system="about:legacy-compat" indent="yes"/>

  <xsl:template match="/">
    <html lang="en">
      <head>
        <meta charset="UTF-8"/>
        <title>Product Catalog</title>
        <style>
          body { font-family: sans-serif; max-width: 800px; margin: 2rem auto; padding: 1rem; }
          table { width: 100%; border-collapse: collapse; }
          th { background: #01696f; color: white; padding: 0.75rem; text-align: left; }
          td { padding: 0.75rem; border-bottom: 1px solid #ddd; }
          .in-stock { color: green; font-weight: bold; }
          .out-of-stock { color: red; }
        </style>
      </head>
      <body>
        <h1>Product Catalog</h1>
        <table>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Description</th>
          </tr>
          <xsl:for-each select="catalog/product">
            <tr>
              <td><xsl:value-of select="@id"/></td>
              <td><xsl:value-of select="name"/></td>
              <td><xsl:value-of select="@category"/></td>
              <td><xsl:value-of select="price/@currency"/>&#160;<xsl:value-of select="price"/></td>
              <td>
                <xsl:choose>
                  <xsl:when test="inStock = 'true'">
                    <span class="in-stock">In Stock</span>
                  </xsl:when>
                  <xsl:otherwise>
                    <span class="out-of-stock">Out of Stock</span>
                  </xsl:otherwise>
                </xsl:choose>
              </td>
              <td><xsl:value-of select="description"/></td>
            </tr>
          </xsl:for-each>
        </table>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>
```

**Step 3:** Apply the transformation:

```bash
# Using xsltproc (pre-installed on macOS/Linux)
xsltproc transform.xsl catalog.xml > output.html

# On Windows, use Saxon-HE (Java):
# java -jar saxon-he.jar -s:catalog.xml -xsl:transform.xsl -o:output.html
```

**Step 4:** Open `output.html` in a browser and verify the table renders correctly.

**Step 5 (extension):** Modify `transform.xsl` to:
- Show only products where `inStock = 'true'` (use `xsl:if`)
- Sort products alphabetically by `name` (use `xsl:sort`)

### Deliverable

All 4 files committed. In `README.md`, explain what XSLT did in plain English — as if explaining to someone who's never seen it.

---

# Git Tasks

---

## Task G1 — Beginner: Your First Real Commit Workflow

**Folder:** `git/projects/beginner-first-commit/`  
**Time:** ~20 minutes  
**What you'll produce:** A commit history + `README.md`

### Instructions

Practice the fundamental Git workflow: stage, commit, check history.

**Step 1:** Make sure you're in your repo root:

```bash
cd dev-fundamentals-portfolio
git status  # Should show a clean state or your current changes
```

**Step 2:** Navigate to the task folder and create some files:

```bash
cd git/projects/beginner-first-commit
echo "# My First Git Task" > README.md
echo "practicing git" > notes.txt
```

**Step 3:** Run through the full workflow — observe the output at each step:

```bash
# What does Git see right now?
git status

# What exactly is different?
git diff

# Stage README.md only
git add README.md
git status  # Notice: README is staged, notes.txt is not

# Stage the rest
git add notes.txt
git status  # Both files staged

# Commit
git commit -m "feat: add beginner git task files"

# See your commit in history
git log --oneline

# See what the commit contains
git show HEAD
```

**Step 4:** Make a second commit:

```bash
echo "Git tracks changes, not files." >> notes.txt
git add notes.txt
git commit -m "docs: add note about how git works"
git log --oneline
```

**Step 5:** Document your output. In `README.md`, paste the output of `git log --oneline` and answer:
- What does the staging area do?
- Why would you stage files individually instead of `git add .`?

### Deliverable

A `README.md` with at least 2 paragraphs explaining what you learned, backed by your actual `git log` output.

---

## Task G2 — Intermediate: Feature Branch Workflow

**Folder:** `git/projects/intermediate-branch-workflow/`  
**Time:** ~35 minutes  
**What you'll produce:** A branch history demonstrating the full PR workflow

### Instructions

Simulate a real team feature development workflow using branches.

**Step 1:** Start from `main` — make sure it's clean:

```bash
git checkout main
git status  # Clean working tree
```

**Step 2:** Create a feature branch and add a file:

```bash
git checkout -b feature/add-library-catalog

# Create a sample JSON file in the branch
cat > git/projects/intermediate-branch-workflow/library.json << 'EOF'
{
  "library": {
    "name": "Dev Library",
    "books": [
      { "id": "B001", "title": "Clean Code", "available": true },
      { "id": "B002", "title": "The Pragmatic Programmer", "available": true }
    ]
  }
}
EOF

git add git/projects/intermediate-branch-workflow/library.json
git commit -m "feat: add initial library catalog JSON"
```

**Step 3:** Make another change on the same branch:

```bash
# Add a README
cat > git/projects/intermediate-branch-workflow/README.md << 'EOF'
# Branch Workflow Task

This folder demonstrates the feature branch workflow.

## Branch used
`feature/add-library-catalog`
EOF

git add git/projects/intermediate-branch-workflow/README.md
git commit -m "docs: add README for branch workflow task"
```

**Step 4:** Go back to `main` and see the difference:

```bash
git checkout main
ls git/projects/intermediate-branch-workflow/  # Files don't exist on main!

git checkout feature/add-library-catalog
ls git/projects/intermediate-branch-workflow/  # Files are back
```

**Step 5:** Merge the feature into `main`:

```bash
git checkout main
git merge feature/add-library-catalog
git log --oneline --graph  # See the merge in history
```

**Step 6:** Clean up:

```bash
git branch -d feature/add-library-catalog  # Delete merged branch
git branch  # Confirm it's gone
```

**Step 7:** Document. In `README.md`, add a section called `What I learned` explaining:
- Why work on a branch instead of directly on `main`
- What happens to a branch after it's merged

---

## Task G3 — Advanced: GitHub Actions CI for JSON + XML Validation

**Folder:** `git/projects/advanced-github-actions/`  
**Time:** ~45 minutes  
**What you'll produce:** A working GitHub Actions workflow that validates all JSON and XML files in the repo

### Instructions

Set up a CI pipeline that runs automatically on every push.

**Step 1:** Create the workflow file:

```bash
mkdir -p .github/workflows
```

Create `.github/workflows/validate.yml`:

```yaml
name: Validate Data Files

on:
  push:
    branches: ["**"]
  pull_request:

jobs:
  validate-json:
    name: Validate JSON files
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: "20"

      - name: Validate all JSON files
        run: |
          ERRORS=0
          for file in $(find . -name "*.json" \
              -not -path "*/node_modules/*" \
              -not -path "*/.git/*"); do
            echo -n "Checking $file ... "
            if node -e "JSON.parse(require('fs').readFileSync('$file','utf8'))" 2>/dev/null; then
              echo "✓"
            else
              echo "✗ INVALID"
              ERRORS=$((ERRORS+1))
            fi
          done
          if [ $ERRORS -gt 0 ]; then
            echo "::error::$ERRORS JSON file(s) failed validation"
            exit 1
          fi
          echo "All JSON files valid."

  validate-xml:
    name: Validate XML files
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Install xmllint
        run: sudo apt-get install -y libxml2-utils

      - name: Validate all XML files
        run: |
          ERRORS=0
          for file in $(find . -name "*.xml" \
              -not -path "*/.git/*" \
              -not -name "*.xsl"); do
            echo -n "Checking $file ... "
            if xmllint --noout "$file" 2>/dev/null; then
              echo "✓"
            else
              echo "✗ INVALID"
              xmllint --noout "$file"
              ERRORS=$((ERRORS+1))
            fi
          done
          if [ $ERRORS -gt 0 ]; then
            echo "::error::$ERRORS XML file(s) failed validation"
            exit 1
          fi
          echo "All XML files valid."
```

**Step 2:** Commit and push:

```bash
git add .github/workflows/validate.yml
git commit -m "ci: add GitHub Actions workflow to validate JSON and XML files"
git push origin main
```

**Step 3:** Go to your GitHub repo → **Actions** tab. Watch the workflow run.

**Step 4:** Introduce a bug to test the CI:

```bash
git checkout -b test/broken-json
echo '{ "invalid": json, }' > test-broken.json
git add test-broken.json
git commit -m "test: add intentionally broken JSON to trigger CI failure"
git push origin test/broken-json
```

Open a PR from `test/broken-json` → `main`. Watch the CI fail on the PR.

**Step 5:** Fix the bug and push again — watch the CI pass.

```bash
echo '{ "valid": "json" }' > test-broken.json
git add test-broken.json
git commit -m "fix: correct broken JSON in test file"
git push origin test/broken-json
```

**Step 6:** Document in `README.md`:
- What CI/CD means in plain English
- Why automated validation matters on a team
- What the workflow does, step by step

---

## Task Completion Tracker

| Task | Topic | Level | Status |
|------|-------|-------|--------|
| J1 — Config File | JSON | Beginner | ☐ |
| J2 — Parse API Feed | JSON | Intermediate | ☐ |
| J3 — JSON-to-XML Converter | JSON + XML | Advanced | ☐ |
| X1 — Library Catalog | XML | Beginner | ☐ |
| X2 — XSD Validation | XML | Intermediate | ☐ |
| X3 — XSLT to HTML | XML + XSLT | Advanced | ☐ |
| G1 — First Commit | Git | Beginner | ☐ |
| G2 — Branch Workflow | Git | Intermediate | ☐ |
| G3 — GitHub Actions CI | Git + JSON + XML | Advanced | ☐ |

Mark tasks complete by changing `☐` to `☑` as you finish them.
